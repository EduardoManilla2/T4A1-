package t4a1.pkg1;

import java.util.Scanner;

public class T4A11 {

    public static void main(String[] args) {
        suma();

    }

    public static void suma() {
        Scanner scanner = new Scanner(System.in);
        int numero = 0;
        System.out.println("Hasta que numero quieres llegar: ");
        int limite = scanner.nextInt();
        
        while (numero < limite) {
            numero ++;
            System.out.println(numero);
        }
    }
}
