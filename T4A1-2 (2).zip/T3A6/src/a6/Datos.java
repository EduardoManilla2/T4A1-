package a6;

public class Datos {
    private int cantidadDeEmpleados;
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String RFC;
    private String CURP;
    private String telefono;
    private String email;
    private int a�osAntiguedad;
    private String numeroDeContrato;
    private int tipoDeEmpleado;
    private String horasLaborales;
    private double salario;
    private double salarioTotal;
    private double ISR;

    public Datos() {
    }

    public Datos(int cantidadDeEmpleados, String nombre, String apellidoPaterno, String apellidoMaterno, String RFC, String CURP, String telefono, String email, int a�osAntiguedad, String numeroDeContrato, int tipoDeEmpleado, String horasLaborales, double salario, double salarioTotal, double ISR) {
        this.cantidadDeEmpleados = cantidadDeEmpleados;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.RFC = RFC;
        this.CURP = CURP;
        this.telefono = telefono;
        this.email = email;
        this.a�osAntiguedad = a�osAntiguedad;
        this.numeroDeContrato = numeroDeContrato;
        this.tipoDeEmpleado = tipoDeEmpleado;
        this.horasLaborales = horasLaborales;
        this.salario = salario;
        this.salarioTotal = salarioTotal;
        this.ISR = ISR; 
    }

    public double getISR() {
        return ISR;
    }

    public void setISR(double ISR) {
        this.ISR = ISR;
    }

    
    public int getCantidadDeEmpleados() {
        return cantidadDeEmpleados;
    }

    public void setCantidadDeEmpleados(int cantidadDeEmpleados) {
        this.cantidadDeEmpleados = cantidadDeEmpleados;
    }

    public int getA�osAntiguedad() {
        return a�osAntiguedad;
    }

    public void setA�osAntiguedad(int a�osAntiguedad) {
        this.a�osAntiguedad = a�osAntiguedad;
    }

   

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public String getRFC() {
        return RFC;
    }

    public void setRFC(String RFC) {
        this.RFC = RFC;
    }

    public String getCURP() {
        return CURP;
    }

    public void setCURP(String CURP) {
        this.CURP = CURP;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
   
    public String getNumeroDeContrato() {
        return numeroDeContrato;
    }

    public void setNumeroDeContrato(String numeroDeContrato) {
        this.numeroDeContrato = numeroDeContrato;
    }

    public int getTipoDeEmpleado() {
        return tipoDeEmpleado;
    }

    public void setTipoDeEmpleado(int tipoDeEmpleado) {
        this.tipoDeEmpleado = tipoDeEmpleado;
    }

    public String getHorasLaborales() {
        return horasLaborales;
    }

    public void setHorasLaborales(String horasLaborales) {
        this.horasLaborales = horasLaborales;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public double getSalarioTotal() {
        return salarioTotal;
    }

    public void setSalarioTotal(double salarioTotal) {
        this.salarioTotal = salarioTotal;
    }
    
    
}
