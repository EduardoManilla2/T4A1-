package a6;

import java.util.Scanner;

public class A6 {

    public static void main(String[] args) {
        registro();
    }

    public static void registro() {
        Scanner scanner = new Scanner(System.in);
        Datos datos = new Datos();

        System.out.println("Ingrese el numero de empledados: ");
        int cantidadDeEmpleados = scanner.nextInt();
        datos.setCantidadDeEmpleados(cantidadDeEmpleados);

        for (int i = 1; i <= cantidadDeEmpleados; i++) {

            System.out.println("+---------------------------------------------+");
            System.out.println("Ingrese datos del empleado\n");
            System.out.println("+---------------------------------------------+");

            System.out.println("Nombre: ");
            String nombre = scanner.next();
            datos.setNombre(nombre);

            System.out.println("\nApellido paterno: ");
            String apellidoPaterno = scanner.next();
            datos.setApellidoPaterno(apellidoPaterno);

            System.out.println("\nApellido materno: ");
            String apellidoMaterno = scanner.next();
            datos.setApellidoMaterno(apellidoMaterno);

            System.out.println("\nRFC del empleado: ");
            String RFC = scanner.next();
            datos.setRFC(RFC);

            System.out.println("\nCURP del empleado: ");
            String CURP = scanner.next();
            datos.setCURP(CURP);

            System.out.println("\nIngrese el correo electronico del empleado: ");
            String email = scanner.next();
            datos.setEmail(email);

            System.out.println("\nTelefono del empleado: ");
            String Telefono = scanner.next();
            datos.setTelefono(Telefono);

            System.out.println("\nNumero de contraro del empleado: ");
            String numeroDeContrato = scanner.next();
            datos.setNumeroDeContrato(numeroDeContrato);

            System.out.println("\nTipo de empleado que es: \nGerente = 1, \nAdministrativo = 2, \nEmpleado = 3");
            int tipoDeEmpleado = scanner.nextInt();
            datos.setTipoDeEmpleado(tipoDeEmpleado);
            
            if (tipoDeEmpleado == 2) {
                System.out.println("Adquiere bono");
            }

            System.out.println("\nIngrese los a�os de antiguedad que tiene en la empresa sea: ");

            int a�osAntiguedad = scanner.nextInt();
            datos.setA�osAntiguedad(a�osAntiguedad);

            if (a�osAntiguedad >= 0 && a�osAntiguedad <= 2) {
                System.out.println("No adquiere bono");
            }
            if (a�osAntiguedad >= 3 && a�osAntiguedad <= 5) {
                System.out.println("Si adquiere bono");
            }
            if (a�osAntiguedad >= 6 && a�osAntiguedad <= 100) {
                System.out.println("Si adquiere bono");
            }

            System.out.println("\nIngrese la cantidad de horas laborales: ");
            String horasLaborales = scanner.next();
            datos.setHorasLaborales(horasLaborales);

            System.out.println("\nSalario mensual del empleado: ");
            int Salario = scanner.nextInt();
            datos.setSalario(Salario);

            if (a�osAntiguedad >= 3 && a�osAntiguedad <= 5 && tipoDeEmpleado != 2) {
                datos.getSalario();
                double salarioFinal = datos.getSalario() + (datos.getSalario() * 0.03);
                datos.setSalarioTotal(salarioFinal);

            } else {
                if (a�osAntiguedad >= 3 && a�osAntiguedad <= 5 && tipoDeEmpleado == 2) {
                    datos.getSalario();
                    double salarioFinal = datos.getSalario() + (datos.getSalario() * 0.04);
                    datos.setSalarioTotal(salarioFinal);
                }

                if (a�osAntiguedad >= 6 && a�osAntiguedad <= 10 && tipoDeEmpleado != 2) {
                    datos.getSalario();
                    double salarioFinal = datos.getSalario() + (datos.getSalario() * 0.08);
                    datos.setSalarioTotal(salarioFinal);

                } else {
                    if (a�osAntiguedad >= 6 && a�osAntiguedad <= 10 && tipoDeEmpleado == 2) {
                        datos.getSalario();
                        double salarioFinal = datos.getSalario() + (datos.getSalario() * 0.12);
                        datos.setSalarioTotal(salarioFinal);
                    }
                }
                double ISR = 0;
                if (Salario >= 0.01 && Salario <= 318) {
                    ISR = ((datos.getSalario() - 0.01) * 1.92) + 0.00;
                    datos.setISR(ISR);
                } else {
                    if (Salario >= 318.01 && Salario <= 2699.40) {
                        ISR = ((datos.getSalario() - 318.01) * 6.40) + 6.15;
                        datos.setISR(ISR);
                    }
                }

                if (Salario >= 2699.41 && Salario <= 4744.05) {
                    ISR = ((datos.getSalario() - 2699.41) * 10.88) + 158.55;
                    datos.setISR(ISR);
                } else {
                    if (Salario >= 4744.06 && Salario <= 5514.75) {
                        ISR = ((datos.getSalario() - 4744.06) * 16.00) + 381.00;
                        datos.setISR(ISR);
                    }
                }

                if (Salario >= 5514.76 && Salario <= 6602.70) {
                    ISR = ((datos.getSalario() - 5514.76) * 17.92) + 504.30;
                    datos.setISR(ISR);
                } else {
                    if (Salario >= 6602.71 && Salario <= 13316.70) {
                        ISR = ((datos.getSalario() - 6602.71) * 21.36) + 699.30;
                        datos.setISR(ISR);
                    }
                }

                if (Salario >= 13316.71 && Salario <= 20988.90) {
                    ISR = ((datos.getSalario() - 13316.71) * 23.52) + 2133.30;
                    datos.setISR(ISR);
                } else {
                    if (Salario >= 20988.91 && Salario <= 40071.30) {
                        ISR = ((datos.getSalario() - 20988.91) * 30.00) + 3937.80;
                        datos.setISR(ISR);
                    }

                }
                if (Salario >= 40071.30 && Salario <= 1000000000) {
                    datos.setISR(0);
                }

                System.out.println("\n+------------------------------------------------+");
                System.out.println("\n+--------------N�mina empleado-------------------+");

                System.out.println("Nombre: " + nombre + " " + apellidoPaterno + " " + apellidoMaterno);
                System.out.println("\nRFC: " + RFC);
                System.out.println("\nCURP: " + CURP);
                System.out.println("\nEmail: " + email);
                System.out.println("\nTelefono: " + Telefono);
                System.out.println("\nA�os de antiguedad: " + a�osAntiguedad);
                System.out.println("\nNumero de contrato: " + numeroDeContrato);
                System.out.println("\nHoras laborales: " + horasLaborales);
                System.out.println("\nSalario bruto: " + Salario);
                System.out.println("\nSalario con bonificacion: " + datos.getSalarioTotal());

                System.out.println("\n+------------------------------------------------+");

                System.out.println("\nISR : " + datos.getISR());

                System.out.println("\n+------------------------------------------------+");
            }
        }
    }
}
