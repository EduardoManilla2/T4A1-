package ciclomientras;

import java.util.Scanner;

public class CicloMientras {

    public static void main(String[] args) {
        ejercicio2();
    }
    
    // 1. Escribir un programa que solicite un número positivo y 
    // nos muestre desde 1 hasta el valor ingresado de uno en uno.
    public static void ejercicio1() {
        
        Scanner scanner = new Scanner(System.in);
        
        int numero = 0;
        
        System.out.print("Hasta dónde quieres llegar: ");
        int limite = scanner.nextInt();
        
        while(numero < limite) {
            numero++;
            System.out.println(numero);
        }
    }
    
    // 2. Una maquiladora confecciona pantalones y recibe 
    // un lote de N piezas para un cliente X. Crear un programa 
    // en Java que solicite la cantidad de piezas a confeccionar 
    // y luego se ingrese las respectivas tallas que pueden ser 
    // S, M, L y XL. Luego, imprimir en pantalla la cantidad de 
    // piezas confeccionadas por talla.
    public static void ejercicio2() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Piezas a confeccionar");
        int npiezas = scanner.nextInt();
        int n = 0, tallaS = 0, tallaM = 0, tallaL = 0, tallaXL = 0;
        
        
        while(n < npiezas) {
            n++;
            
            System.out.print("\nTalla: ");
            String talla = scanner.next();
            
            if (talla.equals("S") || talla.equals("s")) {
                tallaS++;
            } else if (talla.equals("M") || talla.equals("m")) {
                tallaM++;
            } else if (talla.equals("L") || talla.equals("l")) {
                tallaL++;
            } else {
                tallaXL++;
            }
        }
        
        System.out.println("Cantidades por talla: \n"
            + "Chica (S)\t\t" +tallaS + "\n"
            + "Mediana (M)\t\t" + tallaM + "\n"
            + "Grande (L)\t\t" + tallaL + "\n"
            + "Extragrande (XL)\t" +tallaXL);
    }
    
    
    public static void menu() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Elija una opción del menú:\n"
                + "1. Saludar\n"
                + "2. Sumar");
        int opcion = scanner.nextInt();
        
        switch(opcion) {
            case 1:
                System.out.println("Hola Edgar");
                break;
            
            case 2:
                System.out.println("Suma: " + (6+7));
                break;
                
            default:
                System.out.println("Elija una opción correcta");
               
        }
    }
    
    
    
}
