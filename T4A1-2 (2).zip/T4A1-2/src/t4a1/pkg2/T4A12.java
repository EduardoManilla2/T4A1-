package t4a1.pkg2;

import java.util.Scanner;

public class T4A12 {

    public static void main(String[] args) {
        ejercicio2();
    }

    public static void ejercicio2() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Piezas a confeccionar");
        int npiezas = scanner.nextInt();
        int n = 0, tallaM = 0, tallaS = 0, tallaL = 0, tallaXL = 0;

        while (n < npiezas) {
            n++;

            System.out.println("\nTalla: ");
            String talla = scanner.next();

            if (talla.equals("S") || talla.equals("s")) {
                tallaS++;
            } else if (talla.equals("M") || talla.equals("m")) {
                tallaM++;
            } else if (talla.equals("L") || talla.equals("l")) {
                tallaL++;
            } else {
                tallaXL++;
            }
        }
        System.out.println("+---------------------------------------------------+");
        System.out.println("Cantidades por talla: \n"
                + "Chica(S)\t\t" + tallaS + "\n"
                + "Mediana(M)\t\t" + tallaM + "\n"
                + "Grande (l)\t\t" + tallaL + "\n"
                + "Extragrande (LX)\t" + tallaXL );
        System.out.println("+---------------------------------------------------+");
    }
}
